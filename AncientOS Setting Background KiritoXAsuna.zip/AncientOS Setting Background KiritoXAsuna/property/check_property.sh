#!/sbin/sh

lavender=`getprop ro.ancient.version`
if [ "$AncientOS-CIVILIZATION-v3.9-lavender-PRIMEVAL-20200728-0700-GApps" != "true" ]; then
    exit 1
  else 
  exit 00