#sh
echo "ro.com.google.ime.height_ratio=1.0
ro.com.google.ime.corner_key_r=28
ro.com.google.ime.themes_dir=/system/etc/gboard_theme" >> /system/system/product/build.prop
