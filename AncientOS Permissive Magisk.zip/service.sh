#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode

if [ -e /data/media/0/init.log ]; then
rm /data/media/0/init.log
fi

# write logs into /sdcard
echo "CINEMA DISPLAY STATUS : $(cat /sys/module/mdss_fb/parameters/srgb_enabled)" >/data/media/0/init.log
echo "last boot up on $(date +"%d-%m-%Y %r" )" >> /data/media/0/init.log

#disable google service hogger
for apk in $(pm list packages -3 | sed 's/package://g' | sort); do
	pm disable $apk/com.google.android.gms.analytics.AnalyticsService
	pm disable $apk/com.google.android.gms.analytics.AnalyticsJobService
	pm disable $apk/com.google.android.gms.analytics.CampaignTrackingService
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementService
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementJobService
	pm disable $apk/com.google.android.gms.analytics.AnalyticsReceiver
	pm disable $apk/com.google.android.gms.analytics.CampaignTrackingReceiver
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementInstallReferrerReceiver
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementReceiver
	pm disable $apk/com.google.android.gms.measurement.AppMeasurementContentProvider
	pm disable $apk/com.crashlytics.android.CrashlyticsInitProvider
	pm disable $apk/com.google.android.gms.ads.AdActivity
	pm disable $apk/com.google.firebase.iid.FirebaseInstanceIdService
done
